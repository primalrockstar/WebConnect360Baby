import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DashboardScreen from '../screens/DashboardScreen';
import StudyScreen from '../screens/StudyScreen';
import ChapterDetailScreen from '../screens/ChapterDetailScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { Text } from 'react-native';

const Tab = createBottomTabNavigator();
const StudyStack = createNativeStackNavigator();

const StudyStackScreen = () => {
  return (
    <StudyStack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: '#1e293b',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <StudyStack.Screen 
        name="StudyList" 
        component={StudyScreen} 
        options={{ title: 'Curriculum' }}
      />
      <StudyStack.Screen 
        name="ChapterDetail" 
        component={ChapterDetailScreen}
        options={({ route }: any) => ({ title: route.params?.chapter?.title || 'Chapter Detail' })}
      />
    </StudyStack.Navigator>
  );
};

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Dashboard') {
              iconName = '🏠';
            } else if (route.name === 'Study') {
              iconName = '📚';
            } else if (route.name === 'Profile') {
              iconName = '👤';
            }

            return <Text style={{ fontSize: size, color: color }}>{iconName}</Text>;
          },
          tabBarActiveTintColor: '#3b82f6',
          tabBarInactiveTintColor: 'gray',
          tabBarStyle: {
            backgroundColor: '#1e293b',
            borderTopColor: '#334155',
            paddingBottom: 5,
            paddingTop: 5,
          },
          headerStyle: {
            backgroundColor: '#1e293b',
            shadowColor: 'transparent',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        })}
      >
        <Tab.Screen name="Dashboard" component={DashboardScreen} />
        <Tab.Screen 
          name="Study" 
          component={StudyStackScreen} 
          options={{ headerShown: false }}
        />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
