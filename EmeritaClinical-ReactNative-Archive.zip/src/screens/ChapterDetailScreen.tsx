import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { ChapterData } from '../data/EmeritaClinicalCurriculumStructure';

interface ChapterDetailScreenProps {
  route: {
    params: {
      chapter: ChapterData;
    };
  };
  navigation: any;
}

const ChapterDetailScreen: React.FC<ChapterDetailScreenProps> = ({ route, navigation }) => {
  const { chapter } = route.params;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.chapterNumber}>
          {chapter.moduleNumber ? `Module ${chapter.moduleNumber}` : `Chapter ${chapter.chapterNumber}`}
        </Text>
        <Text style={styles.title}>{chapter.title}</Text>
        <Text style={styles.description}>{chapter.description}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Learning Objectives</Text>
        {chapter.learningObjectives.map((objective, index) => (
          <View key={index} style={styles.objectiveItem}>
            <Text style={styles.bulletPoint}>•</Text>
            <Text style={styles.objectiveText}>{objective}</Text>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Topics Covered</Text>
        <View style={styles.topicsContainer}>
          {chapter.topics.map((topic, index) => (
            <View key={index} style={styles.topicTag}>
              <Text style={styles.topicText}>{topic}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.actionsContainer}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => console.log('Navigate to Study Notes')}
        >
          <Text style={styles.actionButtonIcon}>📖</Text>
          <Text style={styles.actionButtonText}>Study Notes</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => console.log('Navigate to Flashcards')}
        >
          <Text style={styles.actionButtonIcon}>🗂️</Text>
          <Text style={styles.actionButtonText}>Flashcards</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.actionButton}
          onPress={() => console.log('Navigate to Quiz')}
        >
          <Text style={styles.actionButtonIcon}>📝</Text>
          <Text style={styles.actionButtonText}>Practice Quiz</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
    backgroundColor: '#1e293b',
  },
  chapterNumber: {
    color: '#3b82f6',
    fontWeight: 'bold',
    fontSize: 14,
    marginBottom: 5,
  },
  title: {
    color: '#ffffff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    color: '#94a3b8',
    fontSize: 16,
    lineHeight: 24,
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  sectionTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  objectiveItem: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  bulletPoint: {
    color: '#3b82f6',
    marginRight: 10,
    fontSize: 16,
  },
  objectiveText: {
    color: '#cbd5e1',
    fontSize: 16,
    flex: 1,
    lineHeight: 24,
  },
  topicsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  topicTag: {
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.2)',
  },
  topicText: {
    color: '#60a5fa',
    fontSize: 14,
  },
  actionsContainer: {
    padding: 20,
    gap: 15,
  },
  actionButton: {
    backgroundColor: '#1e293b',
    padding: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  actionButtonIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ChapterDetailScreen;
