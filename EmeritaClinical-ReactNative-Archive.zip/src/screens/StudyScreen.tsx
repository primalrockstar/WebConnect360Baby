import React from 'react';
import { View, StyleSheet } from 'react-native';
import EmeritaClinicalChapterList from '../components/EmeritaClinicalChapterList';
import { ChapterData } from '../data/EmeritaClinicalCurriculumStructure';

interface StudyScreenProps {
  navigation: any;
}

const StudyScreen: React.FC<StudyScreenProps> = ({ navigation }) => {
  const handleChapterSelect = (chapter: ChapterData) => {
    navigation.navigate('ChapterDetail', { chapter });
  };

  return (
    <View style={styles.container}>
      <EmeritaClinicalChapterList onChapterSelect={handleChapterSelect} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
});

export default StudyScreen;
